export const environment = {
  production: true,
  url_api: 'https://rickandmortyapi.com/api',
  firebase: {
    apiKey: "AIzaSyBAY0ILpb-dk40VaZc276Lztl1unDnN3rE",
    authDomain: "callmemapa-rickandmorty.firebaseapp.com",
    projectId: "callmemapa-rickandmorty",
    storageBucket: "callmemapa-rickandmorty.appspot.com",
    messagingSenderId: "644961981597",
    appId: "1:644961981597:web:761bbe750ebe4aadf63074",
  }
};
